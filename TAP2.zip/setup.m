clear;
close all;
clc;
addpath('./functions');
addpath('./controls');
addpath('./plant');
addpath('./scripts');
addpath('./data');