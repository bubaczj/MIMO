function u = PID_decouple(y_zad, y, t, start, Fm, dist)

    persistent  uch last wind Fmin exec u_temp P1 P2
    if isempty(t)
        t = 0;
    end
    if (isempty(exec) || (t == 0))
        exec = 0;
    end
    if isempty(u_temp) || t == 0
        u_temp = [];
    end
    Ts = 5;
    conn = aeye(2); % eye : 1-1/2-2; aeye : 1-2/2-1
    %% continous
    % k  = 2*[10 1];
    % kd = 0*[1 1];
    % ki = 0.06*[5 1];
    k  = 0.09 * 2.8*[10 1];
    kd = 0*[1 1];
    ki = 0.05*[5 1];
    anti = 10 * [1 1];
    A = anti.* conn;
    Kp = k  .* conn;
    Kd = kd .* conn;
    Ki = ki .* conn;
if nargin > 5
    %% dist = 1 -- distortion +/- 50%, dist = 0 -- no distortion
    distortion([],dist);
    Fmin = Fm;
    load('data.mat');
    del = tr.IODelay;
    tr.IODelay = zeros(2, 4);
    
    if(sum(sum(conn == eye(2))) > 0)
        Gd1 = -tr(1,2)/tr(1,1);
        Gd1.IODelay = max(0, del(1,2)-del(1,1));
        Gd1 = c2d(Gd1, Ts, 'zoh');
        [A1, B1, C1, D1] = tf2ss(cell2mat(Gd1.Numerator), cell2mat(Gd1.Denominator));
        del1 = Gd1.IODelay;
        Gd2 = -tr(2,1)/tr(2,2);
        Gd2.IODelay = max(0, del(2,1)-del(2,2));
        Gd2 = c2d(Gd2, Ts, 'zoh');
        [A2, B2, C2, D2] = tf2ss(cell2mat(Gd2.Numerator), cell2mat(Gd2.Denominator));
        del2 = Gd2.IODelay;
    else
        Gd1 = -tr(2,2)/tr(2,1);
        Gd1.IODelay = max(0, del(1,1)-del(1,2));
        Gd1 = c2d(Gd1, Ts, 'zoh');
        [A1, B1, C1, D1] = tf2ss(cell2mat(Gd1.Numerator), cell2mat(Gd1.Denominator));
        del1 = Gd1.IODelay;
        Gd2 = -tr(1,1)/tr(1,2);
        Gd2.IODelay = max(0, del(2,2)-del(2,1)); 
        Gd2 = c2d(Gd2, Ts, 'zoh');
        [A2, B2, C2, D2] = tf2ss(cell2mat(Gd2.Numerator), cell2mat(Gd2.Denominator));
        del2 = Gd2.IODelay;
    end 
    if isempty(A1), A1 = 0;end
    if isempty(B1), B1 = 0;end
    if isempty(C1), C1 = 0;end
    if isempty(D1), D1 = 0;end
    if isempty(A2), A2 = 0;end
    if isempty(B2), B2 = 0;end
    if isempty(C2), C2 = 0;end
    if isempty(D2), D2 = 0;end
    
    P1 = [A1, B1, C1, D1, del1];
    P2 = [A2, B2, C2, D2, del2];
    
elseif nargin > 3
        last = [0; 0];
        uch = [0; 0];
        wind = [0; 0];
else
    if t >= exec
        exec = Ts*(floor(t/Ts) + 1);
        e  = y_zad - y(1:2);
        uch = uch + e;
        u  = [Kp*e + Ki*uch + Kd*(y-last)/Ts + A*wind; distortion(t)];
        dec1 = decoupler(t, P1(1), P1(2), P1(3), P1(4), u(2), 1, P1(5));
        dec2 = decoupler(t, P2(1), P2(2), P2(3), P2(4), u(1), 2, P2(5));
        u = u + [dec1; dec2; 0; 0];
        if (u(1) + Fmin(1)) < 0 
            wind(1) = u(1) + Fmin(1);
            u(1) = -Fmin(1);
        else
            wind(1) = 0;
        end
        if (u(2) + Fmin(2)) < 0
            wind(2) = u(2) + Fmin(2);
            u(2) = - Fmin(2);
        else
            wind(2) = 0;
        end
        last = y;
        u_temp = u;
    else
        u = u_temp;
    end
end
end

