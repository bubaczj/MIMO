function u = PID(y_zad, y, t, start, Fm, dist)

    persistent  uch last wind Fmin exec u_temp
    if isempty(t)
        t = 0;
    end
    if (isempty(exec) || (t == 0))
        exec = 0;
    end
    if isempty(u_temp) || t == 0
        u_temp = [];
    end
    Ts = 5;
    conn = aeye(2); % eye : 1-1/2-2; aeye : 1-2/2-1
    %% constant
    % k  = .5*[2 1];
    % kd = [0 0];
    % ki = 0.03*[1 0.5]; 
    %% discrete
    k  = 0.6 * 2.1*[2 1];
    kd = [0 0];
    ki = 0.2 * [1 0.5];
    anti = [1 1];
    A = anti.* conn;
    Kp = k  .* conn;
    Kd = kd .* conn;
    Ki = ki .* conn;
if nargin > 5
    %% dist = 1 -- distortion +/- 50%, dist = 0 -- no distortion
    distortion([],dist);
    Fmin = Fm;
elseif nargin > 3
        last = [0; 0];
        uch = [0; 0];
        wind = [0; 0];   
else
    if t >= exec
        exec = Ts*(floor(t/Ts) + 1);
        e  = y_zad - y(1:2);
        uch = uch + e;
        u  = [Kp*e + Ki*uch + Kd*(y-last) + A*wind; distortion(t)];
        if (u(1) + Fmin(1)) < 0 
            wind(1) = u(1) + Fmin(1);
            u(1) = -Fmin(1);
        else
            wind(1) = 0;
        end
        if (u(2) + Fmin(2)) < 0
            wind(2) = u(2) + Fmin(2);
            u(2) = - Fmin(2);
        else
            wind(2) = 0;
        end
        last = y;
        u_temp = u;
    else
        u = u_temp;
    end
end
end

