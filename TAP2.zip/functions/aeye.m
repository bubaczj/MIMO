function I = aeye( n )
    I = fliplr(eye(n));
end

