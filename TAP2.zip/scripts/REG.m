%%%%% Regulacja PID
%%%%% 



clear;
clc;
c = get(gca, 'colororder');
close all;
warning ('off','all');   % LaTeX interpreter warnings


%% Parametry modelu 
load('./data.mat');

[~,~,~, X0, U0] = linAB(data.h0, data.T0, data);          % Wyznaczenie punktu pocz�tkowego

%% Parametry symulacji
step = [0.5; -0.5; 0; 0];                        
step_val = [14, 31, 0, 0]'*[-1,-0.5, 0.5, 1];    
T = [0, 2000 ];                                  % Czas symulacji
Fmin = [Fh0, Fc0];
controlhandle = @DMCn;               % Obs�uga sterowania PID/PID_decouple/DMCa/DMCn
controlhandle([],[],[],[],Fmin, 0.5);
y_zad = [3.73; 40.21].*[0.8 0.9 1.2 1.5; 0.8 0.9 1.2 1.5 ];
%y_zad = [3.73; 40.21].*[0.8 0.9 1.2 1.5; 1 1 1 1 ];
%y_zad = [3.73; 40.21].*[ 1 1 1 1;0.8 0.9 1.2 1.5 ];
options = odeset('MaxStep', 1, 'Refine', 1);    % Ustawienia solvera


%% Symulacja
control_delay([], [], 0);                       % Reset funkcji realizuj�cej op�nienie
controlhandle([], [], [], 0);
solution1 = ode45(@(t, x)plant(t, x, control_delay(t, controlhandle(y_zad(:,1), output_delay(t, x), t)), U0, data), T, X0, options);
[~, t_U1, U1] = control_delay([], [], 1);         % Przebieg sterowania
control_delay([], [], 0);                       % Reset funkcji realizuj�cej op�nienie
controlhandle([], [], [], 0);
solution2 = ode45(@(t, x)plant(t, x, control_delay(t, controlhandle(y_zad(:,2), output_delay(t, x), t)), U0, data), T, X0, options);
[~, t_U2, U2] = control_delay([], [], 1);         % Przebieg sterowania
control_delay([], [], 0);                       % Reset funkcji realizuj�cej op�nienie
controlhandle([], [], [], 0);
solution3 = ode45(@(t, x)plant(t, x, control_delay(t, controlhandle(y_zad(:,3), output_delay(t, x), t)), U0, data), T, X0, options);
[~, t_U3, U3] = control_delay([], [], 1);         % Przebieg sterowania
control_delay([], [], 0);                       % Reset funkcji realizuj�cej op�nienie
controlhandle([], [], [], 0);
solution4 = ode45(@(t, x)plant(t, x, control_delay(t, controlhandle(y_zad(:,4), output_delay(t, x), t)), U0, data), T, X0, options);
[~, t_U4, U4] = control_delay([], [], 1);         % Przebieg sterowania

t = T(1) : T(2);                                % Wektor czasu symulacji
X1 = (deval(solution1, t))';                    % Wektor rozwi�za�
X2 = (deval(solution2, t))';
X3 = (deval(solution3, t))';
X4 = (deval(solution4, t))';

%% Wykresy
figure('NumberTitle', 'off', 'Name', 'Odpowied� modelu nieliniowego na skok');
subplot(2,2,1);
hold on;
plot(t, X1(:,1),t, X2(:,1),t, X3(:,1),t, X4(:,1));
st = [t(1), t(end)];
plot(st, [y_zad(1,1), y_zad(1,1)], 'Color', c(1,:), 'LineStyle', '--');
plot(st, [y_zad(1,2), y_zad(1,2)], 'Color', c(2,:), 'LineStyle', '--');
plot(st, [y_zad(1,3), y_zad(1,3)], 'Color', c(3,:), 'LineStyle', '--');
plot(st, [y_zad(1,4), y_zad(1,4)], 'Color', c(4,:), 'LineStyle', '--');
xlabel('$t[s]$', 'interpreter', 'latex');
ylabel('$h[cm]$', 'interpreter', 'latex');
title('Liquid level', 'interpreter', 'latex');
legend('skok 1','skok 2','skok 3','skok 4', 'location', 'east');
grid on;
xlim(T);

subplot(2,2,2);
t = [0 t + tau];
plot(t,[X1(1,2); X1(:,2)],t,[X2(1,2); X2(:,2)],t,[X3(1,2); X3(:,2)],t,[X4(1,2); X4(:,2)]);
hold on;
plot(st, [y_zad(2,1), y_zad(2,1)], 'Color', c(1,:), 'LineStyle', '--');
plot(st, [y_zad(2,2), y_zad(2,2)], 'Color', c(2,:), 'LineStyle', '--');
plot(st, [y_zad(2,3), y_zad(2,3)], 'Color', c(3,:), 'LineStyle', '--');
plot(st, [y_zad(2,4), y_zad(2,4)], 'Color', c(4,:), 'LineStyle', '--');
xlabel('$t[s]$', 'interpreter', 'latex');
ylabel('$T[{}^\circ C]$', 'interpreter', 'latex');
title('Temperature', 'interpreter', 'latex');
legend('skok 1','skok 2','skok 3','skok 4', 'location', 'east');
grid on;
xlim(T);

t = t(2:end)-tau;

subplot(2,2,3);
plot(t_U1, U1(1,:)+Fh0,t_U2, U2(1,:)+Fh0,t_U3, U3(1,:)+Fh0,t_U4, U4(1,:)+Fh0);
xlabel('$t[s]$', 'interpreter', 'latex');
ylabel('$F_H[\frac{cm^3}{s}]$', 'interpreter', 'latex');
title('Hot water flaw', 'interpreter', 'latex');
legend('skok 1','skok 2','skok 3','skok 4', 'location', 'east');
grid on;
xlim(T);

subplot(2,2,4);
plot(t_U1, U1(2,:)+Fc0,t_U2, U2(2,:)+Fc0,t_U3, U3(2,:)+Fc0,t_U4, U4(2,:)+Fc0);
xlabel('$t[s]$', 'interpreter', 'latex');
ylabel('$F_C[\frac{cm^3}{s}]$', 'interpreter', 'latex');
title('Cold water flaw', 'interpreter', 'latex');
legend('skok 1','skok 2','skok 3','skok 4', 'location', 'east');
grid on;
xlim(T);


